<?php
if (count($_FILES) > 0) {
    if (is_uploaded_file($_FILES['userImage']['tmp_name'])) {
        require_once "db.php";
        $stdNUmber = $_POST['studentNumber'];
        $imgData = addslashes(file_get_contents($_FILES['userImage']['tmp_name']));
        
        //$imageProperties = getimageSize($_FILES['userImage']['tmp_name']);

        //$sql = "INSERT INTO student(studentNumber, StdIdPicture)
	     //       VALUES('{$stdNUmber}','{$imgData}')";
        $sql = "insert into student(StdNumber, StdIdPicture) 
                values('" . $stdNUmber . "','" . $imgData . "')";
        $current_id = mysqli_query($con, $sql) or die("<b>Error:</b> Problem on Image Insert<br/>" . mysqli_error($con));
        if (isset($current_id)) {
            //header("Location: listImages.php");
            echo "Uploaded";
        }
    }
}
?>
<HTML>

<HEAD>
    <TITLE>Upload Image to MySQL BLOB</TITLE>
    <link href="imageStyles.css" rel="stylesheet" type="text/css" />
</HEAD>

<BODY>
    <form name="frmImage" enctype="multipart/form-data" action="" method="post" class="frmImageUpload">
        <label>Upload Image File:</label><br /> 
        <input name="studentNumber" type="text" required/>
        <input name="userImage" type="file" class="inputFile" />
        <input type="submit" value="Submit" class="btnSubmit" />
    </form>
    </div>
</BODY>

</HTML>