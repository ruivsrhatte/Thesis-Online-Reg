<?php 
//$con = mysqli_connect('localhost', 'root', '', 'studentdb_reg_trial');
$con = mysqli_init(); 
mysqli_real_connect($con, "thesis-mysql-server.mysql.database.azure.com", "aleck12123", "Thesisdatabase12123", "studentdb", 3306);

// Check connection
//if ($con->connect_error) {
  // die("Connection failed: " . $con->connect_error);
 // }
 // echo "Connected successfully";
?>